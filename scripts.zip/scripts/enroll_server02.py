import time
import sys

loadProperties('./wls_python.properties')
#startNodeManager(verbose='false', NodeManagerHome='/apps/oracle/middleware/user_projects/domains/auto_domain/nodemanager', ListenPort='5554');
print '###################################################';
print 'Enrolling this machine with the domain directory at';
print '###################################################';
connUri = 't3://'+admAdrs+':'+admPort;
connect(userName,passWord,connUri);
print 'Connected';
print ''

nmEnroll(domainsDirectory+'/'+domainName+'/',domainsDirectory+'/'+domainName+'/''nodemanager')
#shutdown()
disconnect()
os.system("sleep 03")
exit()
