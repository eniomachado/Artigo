#deployJDK(){
#'tar -xvf /apps/installer/jdk-7u65-linux-x64 -C /apps/oracle/java -log=/apps/oracle/oraInventory/logs/jdk-7u65-linux-x64.log' 2>> logs/2.installJDK.log
#'ln -s /apps/oracle/java/jdk1.7.0_65 /apps/oracle/java/jdk1.7' 2>> logs/2.installJDK.log
#    echo "=== APLICANDO CONFIGURACOES NO .bash_profile..."
#'. /home/oracle/.bash_profile' 2>> logs/setupBash.log
#    echo "=== INSTALL ORACLE JDK: done!"
#    echo "=== INSTALL ORACLE JDK "
#}
date
echo "=== INSTALL ORACLE JDK ############################"
echo "=== INSTALL ORACLE JDK  INSTALANDO Oracle JDK "
echo "=== INSTALL ORACLE JDK ############################"
mv logs/2.installJDK.log logs/2.installJDK.log.`date +%y%m%d%H%M%S`
echo `date` 2> logs/2.installJDK.log
servers="s500lxhmlmm01 s500lxhmlmm03"
for srv in $servers ; 
do 
    echo "=== INSTALL ORACLE JDK JDK: installing on $srv... "
    ssh oracle@$srv 'chmod 700 /apps/install/installSilent/jdk-7u65-linux-x64' 2>> logs/2.installJDK.log
   ssh oracle@$srv 'tar -xvf /apps/install/installSilent/jdk-7u65-linux-x64 -C /apps/oracle/java -log=/apps/oracle/oraInventory/logs/jdk-7u65-linux-x64.log'  2>> logs/2.installJDK.log    
   ssh oracle@$srv 'ln -s /apps/oracle/java/jdk1.7.0_65 /apps/oracle/java/jdk1.7' 2>> logs/2.installJDK.log
#ssh oracle@$srv 'cp /apps/oracle/java/jdk1.7.0_65/jre/lib/security/java.security /apps/oracle/java/jdk1.7.0_65/jre/lib/security/java.security.orig'  2>> logs/3.installWEBLOGIC.logs
   # ssh oracle@$srv 'cat /apps/oracle/java/jdk1.7.0_65/jre/lib/security/java.security.orig | sed s/file:/dev/urandom/jrockit16/g > /apps/oracle/middleware/wlserver_10.3/common/bin/commEnv.sh'
   echo "=== APLICANDO CONFIGURACOES NO .bash_profile..."
   echo "=== INSTALL ORACLE JDK: done!"
   echo "=== INSTALL ORACLE JDK "

#	case $srv in
#		s500*mm01)
#	    	echo "=== INSTALL ORACLE JDK JDK: installing on $srv... "
#	    	deployJDK
#	    	;;
#		s500*mm*)
#		echo "=== INSTALL ORACLE JDK JDK: installing on $srv... "
#                deployJDK
#	    	;;	    
#   esac
done
echo `date` 2>> logs/2.installJDK.log
date
# end.
