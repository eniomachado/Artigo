import time
import sys

loadProperties('./wls_python.properties')

connUri = 't3://'+admAdrs+':'+admPort;
print '###############################################';
print 'Starting the Admin Server to test system ...';
print '###############################################';
startServer(admServer, domainName, connUri, userName, passWord, domainsDirectory+'/'+domainName, 'true', 60000, 'false', jvmArgs='-XX:MaxPermSize=125m, -Xmx512m, -XX:+UseParallelGC');
print '############################';
print 'Started the Admin Server';
print '############################';
print ''

print '##############################';
print 'connecting to the Admin Server';
print '##############################';
print ''
connect(userName,passWord,connUri);
print 'Connected';

print '###################################################';
print 'Enrolling this machine with the domain directory at';
print '###################################################';

nmEnroll(domainsDirectory+'/'+domainName+'/',domainsDirectory+'/'+domainName+'/''nodemanager')
shutdown()
#startServer('AdminServer', domainName, connUri, 'weblogic', 'test1234', domainsDirectory+'/'+domainName, 'true', 60000, 'false', jvmArgs='-XX:MaxPermSize=125m, -Xmx512m, -XX:+UseParallelGC');
#disconnect()
exit()
