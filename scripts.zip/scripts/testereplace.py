import shutil
domainsDirectory='/apps/oracle/middleware/user_projects/domains'
domainName = 'auto_domain'
shutil.copy2(domainsDirectory+"/"+domainName+ "/bin/setDomainEnv.sh", domainsDirectory+"/"+domainName+ "/bin/setDomainEnvBKP.sh")
f=open(domainsDirectory+"/"+domainName+ "/bin/setDomainEnv.sh" , 'r')
conteudo = f.read()
f.close()
string_nova = conteudo.replace('-Xms256m -Xmx512m', '-Xms2048m -Xmx2048m')
f=open(domainsDirectory+"/"+domainName+ "/bin/setDomainEnv.sh" , 'w')
f.write(string_nova)
f.close()
