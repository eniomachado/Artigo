import os
import time
loadProperties('./wls_DS.properties')
dsFileName=dsName+'.xml'
connUri = 't3://'+admAdrs+':'+admPort;
print('Starting...')
connect(userName,passWord,connUri)
print 'Connected';
edit()
startEdit()
cd('/')
cmo.createJDBCSystemResource(dsName)

cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName)
cmo.setName(dsName)

cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDataSourceParams/'+dsName)
set('JNDINames',jarray.array([String(dsJNDIName)], String))

cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDriverParams/'+dsName)
cmo.setUrl(dsURL)
cmo.setDriverName(dsDriverName)
#setEncrypted('Password', 'Password_1432903782420', '/apps/oracle/middleware/user_projects/domains/auto_domain/Script1432903628507Config', '/apps/oracle/middleware/user_projects/domains/auto_domain/Script1432903628507Secret')
cmo.setPassword(dsPassword)
cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCConnectionPoolParams/'+dsName)
cmo.setTestTableName(dsTestQuery+'\r\n\r\n')

cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDriverParams/'+dsName+'/Properties/'+dsName)
cmo.createProperty('user')

cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDriverParams/'+dsName+'/Properties/'+dsName+'/Properties/user')
cmo.setValue(dsUserName)

cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDataSourceParams/'+dsName)
cmo.setGlobalTransactionsProtocol('None')

cd('/JDBCSystemResources/testeDS')
set('Targets',jarray.array([ObjectName('com.bea:Name='+clusterName+',Type=Cluster')], ObjectName))

cd('/JDBCSystemResources/'+dsName+'/JDBCResource/'+dsName+'/JDBCDriverParams/'+dsName+'/Properties/'+dsName+'/Properties/user')
cmo.unSet('SysPropValue')
cmo.unSet('EncryptedValue')
cmo.setValue(dsUserName)
#
cd('/JDBCSystemResources/testeDS/JDBCResource/testeDS/JDBCConnectionPoolParams/testeDS')
cmo.setMinCapacity(int(MinCapacity))
cmo.setInitialCapacity(int(InitialCapacity))

cd('/JDBCSystemResources/testeDS/JDBCResource/testeDS/JDBCDriverParams/testeDS/Properties/testeDS/Properties/user')
cmo.unSet('SysPropValue')
cmo.unSet('EncryptedValue')
cmo.setValue(dsUserName)
#
cd('/JDBCSystemResources/testeDS/JDBCResource/testeDS/JDBCConnectionPoolParams/testeDS')
cmo.setShrinkFrequencySeconds(int(ShrinkFrequency))
cmo.setTestConnectionsOnReserve(true)
cmo.setTestFrequencySeconds(int(TestFrequency))
cmo.setTestTableName('SQL BEGIN NULL; END;\r\n')
save()
activate()
exit()
