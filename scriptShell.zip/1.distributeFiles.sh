date
deployCore() {
    scp config/* oracle@$srv:/apps/install/installSilent/config
    scp config/.bash_profile oracle@$srv:/home/oracle
    scp source/*  oracle@$srv:/apps/install/installSilent
    scp scripts/*.py scripts/*.properties oracle@$srv:/apps/install/installSilent/scripts
}
echo "=== INSTALL ORACLE REQUIRED FILES            #############################"
echo "=== INSTALL ORACLE REQUIRED FILES             Deploying software binaries "
echo "=== INSTALL ORACLE REQUIRED FILES            #############################"
mv logs/1.distributeFiles.log logs/1.distributeFiles.log.`date +%y%m%d%H%M%S`
echo `date` 2> logs/1.distributeFiles.log
servers="s500lxhmlmm01 s500lxhmlmm03"
. /apps/install/installSilent/config/wls_shell.properties
#servers=$WLS_SERVERS
for srv in $servers ;
do 
    echo "=== INSTALL ORACLE REQUIRED FILES ************************* $srv ***************************"
    echo "=== INSTALL ORACLE REQUIRED FILES Creating required directories..."
    ssh oracle@$srv 'mkdir -p /apps/install/installSilent/config /apps/install/installSilent/scripts /apps/install/installSilent/security /apps/install/installSilent/bin /apps/oracle/java /apps/oracle/oraInventory/logs' 2>> logs/1.distributeFiles.log

    scp config/oraInst.loc oracle@$srv:/apps/oracle/oraInventory 2>> logs/1.distributeFiles.log

    echo "=== INSTALL ORACLE REQUIRED FILES Deploying Oracle jdk and Oracle WebLogic Server software binaries...."
    deployCore

    echo "=== INSTALL ORACLE REQUIRED FILES  **************** finish distritutin to $srv ****************"
done
echo `date` 2>> logs/1.distributeFiles.log
date
# end.
