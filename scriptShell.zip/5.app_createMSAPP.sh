runUnpackDomain () {
    ssh oracle@$srv '/apps/oracle/middleware/oracle_common/common/bin/./unpack.sh -template=/apps/oracle/middleware/template_domain/'$domainName'.jar -domain=/apps/oracle/middleware/user_projects/domains/'$domainName' -log=/apps/installer/logs/unpack_'$domainName'.log -log_priority=INFO'
}
echo "=== CREATE MANAGE SERVERS FOR APP: ###################################"
echo "=== CREATE MANAGE SERVERS FOR APP:  CRIANDO AS JVM's................. "
echo "=== CREATE MANAGE SERVERS FOR APP: ###################################"
mv logs/5.createMSAPP.log logs/5.createMSAPP.log.`date +%y%m%d%H%M%S`
echo `date` 2> logs/5.createMSAPP.log
#for srv in `cat /etc/hosts | grep ctbc | awk '{print $3}'`;
#servers="s500lxwlstauto01 s500lxwlstauto03"
domainName="auto_domain"
servers="s500lxhmlmm01 s500lxhmlmm03"
for srv in $servers; do
	echo "=== CREATE MANAGE SERVERS FOR APP: MANAGE SERVER: installing on weblogic..."
    case $srv in
        s500*mm01)
		ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh app_createMSAPP.py' 2>> logs/5.createMSAPP.log
		ssh oracle@$srv 'cd /apps/oracle/middleware; cp -r template_domain template_domainBKP; cp -r user_projects user_projectsBKP'
       		ssh oracle@$srv scp /apps/oracle/middleware/template_domain/"$domainName".jar oracle@s500lxhmlmm03:/apps/oracle/middleware/template_domain/
		ssh oracle@$srv rm /apps/oracle/middleware/template_domain/"$domainName".jar
        echo ""
			
#	ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh start_MS_mch01.py'
	;;
	s500*mm03)
		
	 	ssh oracle@$srv 'export JAVA_HOME=/apps/oracle/java/jdk1.7'
	  	ssh oracle@$srv 'export PATH=$JAVA_HOME/bin:/usr/kerberos/bin:/usr/local/bin:/bin:/usr/bin'
        echo "=== UNPACK TEMPLATE DOMAIN: TEMPLATE: unpacking $domainName.jar on $srv..."
		runUnpackDomain
		#ssh oracle@$srv 'rm /apps/oracle/middleware/template_domain/'$domainName'.jar'
	echo "=== UNPACK TEMPLATE DOMAIN: TEMPLATE: done!!!"
		ssh oracle@$srv 'cd /apps/oracle/middleware; cp -r template_domain template_domainBKP; cp -r user_projects user_projectsBKP'
	echo "=== setup setdomainenv...."
        ssh oracle@$srv '. /apps/oracle/middleware/user_projects/domains/auto_domain/bin/./setDomainEnv.sh'
#        ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh start_MS_mch02.py'
            ;;
    esac
done

echo `date` 2>> logs/5.createMSAPP.log
# end.
