from java.io import FileInputStream
from java.io import File
import shutil
import os
import sys


loadProperties('./wls_python.properties')
print '###############################################';
print 'Changing NodeManager User and Password ...';
print '###############################################';

readDomain(domainsDirectory+"/"+domainName)
cd("/SecurityConfiguration/"+domainName)
cmo.setNodeManagerUsername(userName)
cmo.setNodeManagerPasswordEncrypted(passWord)
updateDomain()

# Create boot.properties file for Manage Servers!!!
os.makedirs(domainsDirectory+"/"+domainName+ "/servers/"+ms11+"/security")
f=open(domainsDirectory+"/"+domainName+ "/servers/"+ms11+"/security/boot.properties" , 'w')
f.write('username='+userName + '\n')
f.write('password='+passWord + '\n')
f.flush()
f.close()

# backup nodemanager.properties!!!
shutil.copy2(domainsDirectory+"/"+domainName+ "/nodemanager/nodemanager.properties", domainsDirectory+"/"+domainName+ "/nodemanager/nodemanager.propertiesBKP")
os.remove(domainsDirectory+"/"+domainName+ "/nodemanager/nodemanager.properties")
# Create nodemanager.properties file!!!
#os.makedirs(domainsDirectory+"/"+domainName+ "/nodemanager")
f=open(domainsDirectory+"/"+domainName+ "/nodemanager/nodemanager.properties" , 'w')
f.write('DomainsFile='+domainsDirectory+"/"+domainName+'/nodemanager/nodemanager.domains\n')
f.write('LogLimit=0\n')
f.write('PropertiesVersion=12.1.3\n')
f.write('AuthenticationEnabled=true\n')
f.write('NodeManagerHome='+domainsDirectory+"/"+domainName+'/nodemanager\n')
f.write('JavaHome='+javaPath)
f.write('\n')
f.write('LogLevel=INFO\n')
f.write('DomainsFileEnabled=true\n')
f.write('StartScriptName=startWebLogic.sh\n')
f.write('ListenAddress='+listenAdd01)
f.write('\n')
f.write('NativeVersionEnabled=true\n')
f.write('ListenPort='+listenPort)
f.write('\n')
f.write('LogToStderr=true\n')
f.write('SecureListener=false\n')
f.write('LogCount=1\n')
f.write('StopScriptEnabled=false\n')
f.write('QuitEnabled=false\n')
f.write('LogAppend=true\n')
f.write('StateCheckInterval=500\n')
f.write('CrashRecoveryEnabled=false\n')
f.write('StartScriptEnabled=true\n')
f.write('LogFile='+domainsDirectory+"/"+domainName+'/nodemanager/nodemanager.log\n')
f.write('LogFormatter=weblogic.nodemanager.server.LogFormatter\n')
f.write('ListenBacklog=50')
f.flush()
f.close()

connUri = 't3://'+admAdrs+':'+admPort;
print '###############################################';
print 'Starting the Admin Server to test system ...';
print '###############################################';
startServer(admServer, domainName, connUri, userName, passWord, domainsDirectory+'/'+domainName, 'true', 60000, 'false', jvmArgs='-XX:MaxPermSize=125m, -Xmx512m, -XX:+UseParallelGC');
print '############################';
print 'Started the Admin Server';
print '############################';
print ''
print '##############################';
print 'connecting to the Admin Server';
print '##############################';
print ''
connect(userName,passWord,connUri);
print 'Connected';
shutdown()
os.system("sleep 08")
exit()
