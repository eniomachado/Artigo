###############################################################
# Criando Maganer Server e Cluster..........................!!!
###############################################################

import time
import sys

loadProperties('./wls_python.properties')

connUri = 't3://'+admAdrs+':'+admPort;

print 'connecting to the Admin Server';
connect(userName,passWord,connUri);
print 'Connected';

edit()
startEdit()

cd('/')
print 'Criando o segundo managed server...'
cmo.createServer(ms12)

cd('/Servers/'+ms12)
cmo.setListenAddress(listenAdd01)
cmo.setListenPort(int(msPort03))

cd('/')
print 'Criando o terceiro managed server...'
cmo.createServer(ms32)

cd('/Servers/'+ms32)
cmo.setListenAddress(listenAdd03)
cmo.setListenPort(int(msPort04))
save()
activate(block='true')

print 'Assign the first server to the cluster'

startEdit()
cd('/Servers/'+ms12)
cmo.setCluster(getMBean('/Clusters/'+clusterName))

print 'Assign the second server to the cluster'
cd('/Servers/'+ms32)
cmo.setCluster(getMBean('/Clusters/'+clusterName))

save()
activate(block='true')

print 'Adicionando o segundo manage server para machine01'

startEdit()

cd('/Servers/'+ms12)
cmo.setMachine(getMBean('/Machines/'+machine01))

print 'Adicionando o segundo manage server para machine03'
cd('/Servers/'+ms32)
cmo.setMachine(getMBean('/Machines/'+machine03))
save()
activate(block='true')
print ''
print 'Existing...';
exit();
