runPackDomain() {
	ssh oracle@$srv '/apps/oracle/middleware/oracle_common/common/bin/./pack.sh -domain=/apps/oracle/middleware/user_projects/domains/'$domainName' -template=/apps/oracle/middleware/template_domain/'$domainName'.jar -template_name='$domainName' -managed=true -log=logs/'pack_$domainName'.log -log_priority=INFO'
}
echo "=== CREATE ORACLE WEBLOGIC DOMAIN: ###################################"
echo "=== CREATE ORACLE WEBLOGIC DOMAIN:  INSTALANDO Oracle WebLogic Domain "
echo "=== CREATE ORACLE WEBLOGIC DOMAIN: ###################################"
mv logs/4.installDOMAIN12C.log logs/4.installDOMAIN12C.log.`date +%y%m%d%H%M%S`
echo `date` 2> logs/4.installDOMAIN12C.log
#for srv in `cat /etc/hosts | grep magazineluiza | awk '{print $3}'`;
. '/apps/install/installSilent/config/wls_shell.properties'
for srv in $Admservers ;
do
echo "=== INSTALL ORACLE WEBLOGIC DOMAIN: DOMAIN: installing on $srv..."
    ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh app_configureDomain.py' 2>> logs/5.createMSAPP.log
	echo "==== RUNNING DOMAIN PACK: Starting Pack... "
	runPackDomain
  # ssh oracle@$srv
        #sh /apps/oracle/bin/checkList.sh
echo "==== CREATE ORACLE WEBLOGIC DOMAIN: WEBLOGIC DOMAIN: done!"
echo ""
echo "==== DOMAIN PACK: Done... "
done
echo `date` 2>> logs/4.installDOMAIN12C.log
