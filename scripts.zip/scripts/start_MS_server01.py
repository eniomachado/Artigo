import sys

loadProperties('./wls_python.properties')
print '###################################################';
print 'Testing Node Manager Connection...                 ';
print '###################################################';
connUri = 't3://'+admAdrs+':'+admPort;
#connUri = 't3://s500lxwlstauto01.magazineluiza.intranet:7080';
#nmConnect('weblogic','test1234','s500lxhmlmm01','5554','auto_domain','/apps/oracle/middleware/user_projects/domains/auto_domain','plain')
#nmConnect('weblogic','teste1234',admAdrs,'5554',domainName,domainsDirectory+'/'+domainName,'plain')
nmConnect(userName,passWord,listenAdd01,listenPort,domainName,domainsDirectory+'/'+domainName,'plain')
print '###################################################';
print 'Starting Manage Servers                            ';
print '###################################################';
nmStart(admServer)
os.system("sleep 20")
nmServerStatus(admServer)
connect(userName,passWord,connUri);
domainRuntime()
cd ('ServerLifeCycleRuntimes/'+ms11)
cmo.start()
#os.system("sleep 08")
nmDisconnect()
exit()
