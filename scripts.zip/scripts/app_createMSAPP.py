###############################################################
# Criando Maganer Server e Cluster..........................!!!
###############################################################

import time
import sys

loadProperties('./wls_python.properties')


connUri = 't3://'+admAdrs+':'+admPort;
print '###############################################';
print 'Starting the Admin Server to test system ...';
print '###############################################';
startServer(admServer, domainName, connUri, userName, passWord, domainsDirectory+'/'+domainName, 'true', 60000, 'false', jvmArgs='-XX:MaxPermSize=125m, -Xmx512m, -XX:+UseParallelGC');
print '############################';
print 'Started the Admin Server';
print '############################';
print ''
print 'connecting to the Admin Server';
connect(userName,passWord,connUri);
print 'Connected';

edit()
startEdit()

cd('/')
print 'Create a first managed server...'
cmo.createServer(ms11)

cd('/Servers/'+ms11)
cmo.setListenAddress(listenAdd01)
cmo.setListenPort(int(msPort01))

cd('/')
print 'Create a sencond managed server...'
cmo.createServer(ms31)

cd('/Servers/'+ms31)
cmo.setListenAddress(listenAdd03)
cmo.setListenPort(int(msPort02))
save()
activate(block='true')

print '#####################################'
print 'creating cluster... clusterName'
print '#####################################'

startEdit()
cd('/')
cmo.createCluster(clusterName)

cd ('/Clusters/'+clusterName)
cmo.setClusterMessagingMode('unicast')
print '#####################################'
print 'Cluster Created: clusterName'
print '#####################################'
save()
activate(block='true')

print 'Assign the first server to the cluster'

startEdit()
cd('/Servers/'+ms11)
cmo.setCluster(getMBean('/Clusters/'+clusterName))

print 'Assign the second server to the cluster'
cd('/Servers/'+ms31)
cmo.setCluster(getMBean('/Clusters/'+clusterName))

save()
activate(block='true')

print '#####################################'
print 'adding machine... machine01'
print '#####################################'
startEdit()

cd('/')
cmo.createUnixMachine(machine01)

print '#####################################'
print 'configure a Plain NodeManager...'
print '#####################################'

cd('/Machines/'+machine01+'/NodeManager/'+machine01)
cmo.setNMType('Plain')
cmo.setListenAddress(listenAdd01)
cmo.setListenPort(int(listenPort))
print '#####################################'
print 'UNIX MACHINE CREATED... machine01'
print '#####################################'

print '#####################################'
print 'adding machine... machine03'
print '#####################################'
cd('/')
cmo.createUnixMachine(machine03)

print '#####################################'
print 'configure a Plain NodeManager...'
print '#####################################'

cd('/Machines/'+machine03+'/NodeManager/'+machine03)
cmo.setNMType('Plain')
cmo.setListenAddress(listenAdd03)
cmo.setListenPort(int(listenPort))
print '#####################################'
print 'UNIX MACHINE CREATED... machine02'
print '#####################################'
save()
activate(block='true')
print 'Assign the first server to the machine01'

startEdit()

cd('/Servers/'+ms11)
cmo.setMachine(getMBean('/Machines/'+machine01))

print 'Assign the second server to the machine03'
cd('/Servers/'+ms31)
cmo.setMachine(getMBean('/Machines/'+machine03))
save()
activate(block='true')
shutdown();
disconnect()
os.system("sleep 15")
print ''
print 'Existing...';
exit();
