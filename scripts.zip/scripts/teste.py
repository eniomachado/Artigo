import sys

#loadProperties('. /apps/install/installSilent/config/wls_python.properties')
loadProperties('./wls_python.properties')
