date
echo "=== INSTALL ORACLE WEBLOGIC SERVER: ############################"
echo "=== INSTALL ORACLE WEBLOGIC SERVER:  INSTALANDO Oracle WebLogic "
echo "=== INSTALL ORACLE WEBLOGIC SERVER: ############################"
mv logs/3.installWEBLOGIC.log logs/3.installWEBLOGIC.log.`date +%y%m%d%H%M%S`
echo `date` 2> logs/3.installWEBLOGIC.log
#for srv in `cat /etc/hosts | grep magazineluiza | awk '{print $3}'`;
. '/apps/install/installSilent/config/wls_shell.properties'
for srv in $servers ; 
do

echo '##############################################################' $srv
    echo "=== INSTALL ORACLE WEBLOGIC SERVER: WEBLOGIC: installing on $srv..."
   # ssh oracle@$srv 'mkdir /apps/oracle/middleware'  2>> logs/3.installWEBLOGIC.log
	ssh oracle@$srv '. /home/oracle/.bash_profile' 2>> logs/3.installWEBLOGIC.log
	ssh oracle@$srv $JAVA_HOME'/bin/java -Djava.security.egd=file:/dev/./urandom -Djava.io.tmpdir=/apps/install/installSilent -jar /apps/install/installSilent/fmw_12.1.3.0.0_wls.jar -silent -responseFile /apps/install/installSilent/config/wls12c_silent.rsp -invPtrLoc /apps/oracle/oraInventory/oraInst.loc' 2>> logs/3.installWEBLOGIC.log
	ssh oracle@$srv 'cp '$WLS_COMMON'/commEnv.sh '$WLS_COMMON'/commEnv.sh.orig'  2>> logs/3.installWEBLOGIC.log
    	ssh oracle@$srv 'cat '$WLS_COMMON'/commEnv.sh.orig | sed s/jdk1.7.0_65/jdk1.7/g > '$WLS_COMMON'/commEnv.sh'  2>> logs/3.installWEBLOGIC.log
    	ssh oracle@$srv 'mkdir -p '$WLS_TEMPL'' 2>> logs/3.installWEBLOGIC.log 
    
    echo "=== INSTALL ORACLE WEBLOGIC SERVER: WEBLOGIC: done!"
done
echo `date` 2>> logs/3.installWEBLOGIC.log
# end.
date
