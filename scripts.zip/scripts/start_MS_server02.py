import sys

loadProperties('./wls_python.properties')
print '###################################################';
print 'Testing Node Manager Connection...                 ';
print '###################################################';
connUri = 't3://'+admAdrs+':'+admPort;
#nmConnect(userName,passWord,listenAdd01,'5554',domainName,'/apps/oracle/middleware/user_projects/domains/auto_domain','plain')
nmConnect(userName,passWord,listenAdd01,listenPort,domainName,domainsDirectory+'/'+domainName,'plain')
connect(userName,passWord,connUri);
print '###################################################';
print 'Starting Manage Servers...                         ';
print '###################################################';
domainRuntime()
cd ('ServerLifeCycleRuntimes/'+ms31)
cmo.start()
nmDisconnect()
exit()
