###############################################################
# Criando um dominio simples com somente um admin server !!
###############################################################
from java.io import FileInputStream
from java.io import File
import shutil
import os
import sys

loadProperties('./wls_python.properties')

#print '###############################################';
#print 'Change urandom java                            ';
#print '###############################################';

#shutil.copy2(javaPath+"/jre/lib/security/java.security", javaPath+"/jre/lib/security/java.securityBKP")
#f=open(javaPath+"/jre/lib/security/java.security" , 'r')
#conteudo = f.read()
#f.close()
#string_nova = conteudo.replace('file:/dev/urandom', 'file:/dev/./urandom')
#f=open(javaPath+"/jre/lib/security/java.security" , 'w')
#f.write(string_nova)
#f.close()

readTemplate('/apps/oracle/middleware/wlserver/common/templates/wls/wls.jar')

print ' Criando o dominio...'

# Setting listen address/Port
cd('/Servers/AdminServer')
set('ListenAddress',listenAdd01)
set('ListenPort',int(listenPort01))
# SSL Setting
create('AdminServer','SSL')
cd('SSL/AdminServer')
set('Enabled', 'False')
set('ListenPort',int(listenPortSsl))
#
set('HostnameVerificationIgnored', 'true')
#
cd('/Security/base_domain/User/weblogic')
cmo.setName(userName)
cmo.setPassword(passWord)
#
#setOption('CreateStartMenu', 'false')
setOption('ServerStartMode', 'prod')
setOption('JavaHome', javaPath)

setOption('OverwriteDomain','false')

print 'Writing Domain: '+ domainsDirectory+'/'+domainName;
writeDomain(domainsDirectory+'/'+domainName);
closeTemplate();
print '###############################################';
print 'Domain Created'
print '###############################################';
print ''
print '###############################################';
print 'Change heap setDomainEnv.sh file!              ';
print '###############################################';

shutil.copy2(domainsDirectory+"/"+domainName+ "/bin/setDomainEnv.sh", domainsDirectory+"/"+domainName+ "/bin/setDomainEnvBKP.sh")
f=open(domainsDirectory+"/"+domainName+ "/bin/setDomainEnv.sh" , 'r')
conteudo = f.read()
f.close()
string_nova = conteudo.replace('-Xms256m -Xmx512m', '-Xms2048m -Xmx2048m')
f=open(domainsDirectory+"/"+domainName+ "/bin/setDomainEnv.sh" , 'w')
f.write(string_nova)
f.close()
print ''
print '###############################################';
print 'Create boot.properties file !                  ';
print '###############################################';
# Create boot.properties file !
os.makedirs(domainsDirectory+"/"+domainName+ "/servers/"+admServer+"/security")
f=open(domainsDirectory+"/"+domainName+ "/servers/"+admServer+"/security/boot.properties" , 'w')
f.write('username='+userName)
f.write('\n')
f.write('password='+passWord)
f.flush()
f.close()
print ''
connUri = 't3://'+admAdrs+':'+admPort;
print '###############################################';
print 'Starting the Admin Server to test system ...';
print '###############################################';
startServer(admServer, domainName, connUri, userName, passWord, domainsDirectory+'/'+domainName, 'true', 60000, 'false', jvmArgs='-XX:MaxPermSize=125m, -Xmx512m, -XX:+UseParallelGC');
print '###############################################';
print 'Started the Admin Server';
print '###############################################';
print ''
print '###############################################';
print 'connecting to the Admin Server';
print '###############################################';

#connecting to the Admin Server
connect(userName,passWord,connUri);
print 'Connected';
print ''
print '###############################################';
print 'Shutting down the Admin Server...              ';
print '###############################################';
shutdown();
print 'Existing...';
disconnect()
exit();
