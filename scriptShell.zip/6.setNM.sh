echo "=== CREATE MANAGE SERVERS FOR APP: ###################################"
echo "=== CREATE MANAGE SERVERS FOR APP:  CONFIGURANDO NODE MANAGER........ "
echo "=== CREATE MANAGE SERVERS FOR APP: ###################################"
mv logs/6.setNM.log logs/5.setNM.log.`date +%y%m%d%H%M%S`
echo `date` 2> logs/5.createMSAPP.log
#for srv in `cat /etc/hosts | grep ctbc | awk '{print $3}'`;
#servers="s500lxwlstauto01 s500lxwlstauto03"
domainName="auto_domain"
servers="s500lxhmlmm01 s500lxhmlmm03"
for srv in $servers; do
        echo "=== CREATE MANAGE SERVERS FOR APP: MANAGE SERVER: installing on weblogic..."
    case $srv in
        s500*mm01)
	echo "=== SETTING nodemanager.properties on $srv !!!"
                ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh setup_nm_server01.py'
        echo ""
        echo "=== START NM: starting node manager on weblogic..."
        echo ""
                ssh oracle@$srv '/apps/oracle/middleware/user_projects/domains/auto_domain/bin/startNodeManager.sh &> /apps/oracle/middleware/user_projects/domains/auto_domain/bin/nodemanager.nohup &'
                sleep 100
        echo ""
        echo "=== START NM: NODE MANAGER: Done!!!"
        echo ""
        echo ""
        echo "=== STOP NM: shutting down node manager on weblogic..."
        echo ""
                ssh oracle@$srv '/apps/oracle/middleware/user_projects/domains/auto_domain/bin/stopNodeManager.sh &> /apps/oracle/middleware/user_projects/domains/auto_domain/bin/nodemanager.nohup &'
                sleep 15
        echo ""
        echo "=== STOP NM: NODE MANAGER: Done!!!"
        echo ""
        echo "=== ENROLLING nodemanager on $srv !!!"
                ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh enroll_server01.py'
        echo ""
        echo "=== START NM: starting node manager on weblogic..."
        echo ""
                ssh oracle@$srv '/apps/oracle/middleware/user_projects/domains/auto_domain/bin/startNodeManager.sh &> /apps/oracle/middleware/user_projects/domains/auto_domain/bin/nodemanager.nohup &'
                sleep 100
        echo ""
        echo "=== START NM: NODE MANAGER: Done!!!"
        echo ""

        ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh start_MS_server01.py'
        ;;
        s500*mm03)

                ssh oracle@$srv 'export JAVA_HOME=/apps/oracle/java/jdk1.7'
                ssh oracle@$srv 'export PATH=$JAVA_HOME/bin:/usr/kerberos/bin:/usr/local/bin:/bin:/usr/bin'
        echo "=== SETTING nodemanager.properties on $srv !!!"
                ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh setup_nm_server02.py'
        echo ""
        echo "=== START NM: starting node manager on weblogic..."
        echo ""
                ssh oracle@$srv '/apps/oracle/middleware/user_projects/domains/auto_domain/bin/startNodeManager.sh &> /apps/oracle/middleware/user_projects/domains/auto_domain/bin/nodemanager.nohup &'
                sleep 100
        echo ""
        echo "=== START NM: NODE MANAGER: Done!!!"
        echo ""
        echo ""
        echo "=== STOP NM: shutting down node manager on weblogic..."
        echo ""
                ssh oracle@$srv '/apps/oracle/middleware/user_projects/domains/auto_domain/bin/stopNodeManager.sh &> /apps/oracle/middleware/user_projects/domains/auto_domain/bin/nodemanager.nohup &'
                sleep 15
        echo ""
        echo "=== STOP NM: NODE MANAGER: Done!!!"
        echo ""
        echo "=== ENROLLING nodemanager on $srv !!!"
                ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh enroll_server02.py'
        echo ""
        echo "=== START NM: starting node manager on weblogic..."
        echo ""
                ssh oracle@$srv '/apps/oracle/middleware/user_projects/domains/auto_domain/bin/startNodeManager.sh &> /apps/oracle/middleware/user_projects/domains/auto_domain/bin/nodemanager.nohup &'
                sleep 100
        echo ""
        echo "=== START NM: NODE MANAGER: Done!!!"
        echo ""
        echo "=== setup setdomainenv...."
        ssh oracle@$srv '. /apps/oracle/middleware/user_projects/domains/auto_domain/bin/./setDomainEnv.sh'
        ssh oracle@$srv 'cd /apps/install/installSilent/scripts; /apps/oracle/middleware/wlserver/common/bin/./wlst.sh start_MS_server02.py'
            ;;
    esac
done

echo `date` 2>> logs/5.createMSAPP.log
# end.
