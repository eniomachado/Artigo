loadProperties('./wls_python.properties')
connUri = 't3://'+admAdrs+':'+admPort;

print('Starting...')
connect(userName,passWord,connUri)
print 'Connected';
print('Starting a edit session')
edit()
startEdit()
# Create a new Mbean ( a JDBC resource)
cd('/')
cmo.createJDBCSystemResource(ds1)
#Naming the datasource
cd('/JDBCSystemResources/'+ds1+'/JDBCResource/'+ds1)
cmo.setName(ds1)
#Setting JNDI name
cd('/JDBCSystemResources/'+ds1+'/JDBCResource/'+ds1+'/JDBCDataSourceParams/'+ds1)
set('JNDINames',jarray.array([String(ds1)], String))
cd('/JDBCSystemResources/'+ds1+'/JDBCResource/'+ds1+'/JDBCDriverParams/'+ds1)
cmo.setUrl(datasourceURL)
cmo.setDriverName(datasourceDrive)
cmo.setPassword('PBPUBLIC')
#Set Connection Pool specific parameters
# refer: e-docs.bea.com/wls/docs92/wlsmbeanref/mbeans/JDBCConnectionPoolParamsBean.html
cd('/JDBCSystemResources/'+ds1+'/JDBCResource/'+ds1+'/JDBCConnectionPoolParams/'+ds1)
cmo.setTestConnectionsOnReserve(true)
cmo.setTestTableName(dsTestQuery)
cmo.setConnectionReserveTimeoutSeconds(25)
cmo.setMaxCapacity(20)
cmo.setConnectionReserveTimeoutSeconds(10)
cmo.setTestFrequencySeconds(360)
# Setting the user name
cd('/JDBCSystemResources/'+ds1+'/JDBCResource/'+ds1+'/JDBCDriverParams/'+ds1+'/Properties/'+ds1)
cmo.createProperty('user')
cd('/JDBCSystemResources/'DS1'/JDBCResource/'DS1'/JDBCDriverParams/'DS1'/Properties/'DS1'/Properties/'user)
cmo.setValue('PBPUBLIC')
# Setting the database name
cd('/JDBCSystemResources/'DS1'/JDBCResource/'DS1'/JDBCDriverParams/'DS1'/Properties/'DS1)
cmo.createProperty('databaseName')
cd('/JDBCSystemResources/DS1/JDBCResource/DS1/JDBCDriverParams/DS1/Properties/DS1/Properties/databaseName')
cmo.setValue('jdbc:pointbase:server://localhost:9092/demo')
# Transaction
cd('/JDBCSystemResources/DS1/JDBCResource/DS1/JDBCDataSourceParams/DS1')
cmo.setGlobalTransactionsProtocol('TwoPhaseCommit')
cd('/JDBCSystemResources/DS1')
# targets the DS1 to Cluster
set('Targets',jarray.array([ObjectName('com.bea:Name='+clusterName+',Type=Cluster')], ObjectName))
# targets the DS1 to Servers(AdminServer,MS)
#set('Targets',jarray.array([ObjectName('com.bea:Name=AdminServer,Type=Server'), ObjectName('com.bea:Name=MS,Type=Server')], ObjectName))
activate()
print('Exiting...')
exit()
ds1=testeDS
#Used if the target is a managed server
#datasource.target=Servers/sample_server
#Used if the target is a cluster
#datasource.target=Clusters/sample_cluster
datasource.jndiname=jdbc/SampleDataSource
datasourceDrive=oracle.jdbc.OracleDriver
datasourceURL=jdbc:oracle:thin:@localhost:1521:orcl
datasource.username=sample
datasource.password=welcome1

datasource.initialCapacity=1
datasource.maxCapacity=10
#datasource.shrinkPeriodMinutes=
dsTestQuery=SQL SELECT * FROM DUAL
