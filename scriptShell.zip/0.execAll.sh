#
tempoinicio='date'
echo 'tempoinicio'
1.distributeFiles.sh && 2.installJDK.sh && 3.installWEBLOGIC.sh && 4.installDomain12c.sh && 5.app_createMSAPP.sh && 6.setNM.sh
tempofinal='date'
echo 'tempofinal'
