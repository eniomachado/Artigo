print '###############################################';
print 'Change urandom java                            ';
print '###############################################';

shutil.copy2(javaPath+"/jre/lib/security/java.security", javaPath+"/jre/lib/security/java.securityBKP")
f=open(javaPath+"/jre/lib/security/java.security" , 'r')
conteudo = f.read()
f.close()
string_nova = conteudo.replace('file:/dev/urandom', 'file:/dev/./urandom')
f=open(javaPath+"/jre/lib/security/java.security" , 'w')
f.write(string_nova)
f.close()
