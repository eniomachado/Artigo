import os
import time
loadProperties('./wls_DS.properties')
dsFileName=dsName+'.xml'
oracleHome = os.environ.get(ORACLE_HOME)
appPath= oracleHome + 'soa/connectors/DbAdapter.rar'
planPath=oracleHome + 'soa/connectors/DbAdapterPlanGenerated.xml'
connUri = 't3://'+admAdrs+':'+admPort;
print('Starting...')
connect(userName,passWord,connUri)
print 'Connected';
edit()
startEdit()

appName='DbAdapter'
moduleOverrideName=appName+'.rar'
moduleDescriptorName='META-INF/weblogic-ra.xml'
def makeDeploymentPlanVariable(wlstPlan, name, value, xpath, origin='planbased'):
while wlstPlan.getVariableAssignment(name, moduleOverrideName, moduleDescriptorName):
wlstPlan.destroyVariableAssignment(name, moduleOverrideName, moduleDescriptorName)
while wlstPlan.getVariable(name):
wlstPlan.destroyVariable(name)
variableAssignment = wlstPlan.createVariableAssignment( name, moduleOverrideName, moduleDescriptorName )
variableAssignment.setXpath( xpath )
variableAssignment.setOrigin( origin )
wlstPlan.createVariable( name, value )
             def main():
                     connect(userName,passWord,connUri)
                     edit()
                           try:
                           startEdit()
                           planPath = get('/AppDeployments/DbAdapter/PlanPath')
                           print '__ Using plan ' + planPath
                           myPlan=loadApplication(appPath, planPath)
                           print '___ BEGIN change plan'
                           makeDeploymentPlanVariable(myPlan, 'ConnectionInstance_' '+ CFName' +'_JNDIName_abc123XXX','+ CFName', '/weblogic-connector/outbound-resource-adapter/connection-definition-group/[connection-factory-interface="javax.resource.cci.ConnectionFactory"]/connection-instance/[jndi-name="'+ CFName + '"]/jndi-name')
                           makeDeploymentPlanVariable(myPlan, 'ConfigProperty_xADataSourceName_'+ dsName +'_abc123XXX',dsName, '/weblogic-connector/outbound-resource-adapter/connection-definition-group/[connection-factory-interface="javax.resource.cci.ConnectionFactory"]/connection-instance/[jndi-name="'+ CFName + '"]/connection-properties/properties/property/[name="xADataSourceName"]/value')
                           print '___ DONE change plan'
                           myPlan.save();
                           save();
                           activate(block='true');
                           cd('/AppDeployments/DbAdapter/Targets');

                           redeploy(appName, planPath,targets=cmo.getTargets());
                           print 'EIS Connection factory ' + CFName + 'using' + dsName + ' configured';
                    except:
                           stopEdit('y')
main()
save()
activite()
exit()
