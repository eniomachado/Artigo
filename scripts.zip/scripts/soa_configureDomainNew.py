#Conditionally import wlstModule only when script is executed with jython
if __name__ == '__main__':
from wlstModule import *@UnusedWildImport
import os

# Set beaHome to the one matching your environment

beaHome="/apps/oracle/middleware"
wlHome=beaHome"/wlserver"
baseHome="/apps/oracle"

# Set sprName to the prefix that the RCU schemas and the domain will use

sprName="SILTST"
sprDomain="soaprd_"
# Modify domain name based on your requirements, for this test it is sprName concatenaded with the word "domain"

domainName=sprDomain+"domain"

# Use dbhost, dbport and dbservice based on your RDBMS installation. 

# Make sure you use the servicename and not the ORACLE_SID, as that will cause errors.

dbhost="mldecompkg.magazineluiza.intranet"
dbport="1521"
dbservice="MLDECOM"

rcudbstr=dbhost+":"+dbport+":"+dbservice

dburl="jdbc:oracle:thin:@"+dbhost+":"+dbport+"/"+dbservice

# Customize the directory were the passwords file is located, as per the step 1)

pwdfile="/apps/install/installSilent/config/passwordfile.txt"

print "beaHome="+beaHome
print "wlHome="+wlHome
print "domain="+domainName
print "baseHome="+baseHome
print "schemaprefix="+sprName
print "Connection String for RCU: "+rcudbstr
print "Connection String for Datasources: "+dburl

## Set up schemas with RCU GUI.

# The following command can be used to DROP an existing schema. Uncomment if needed
# os.system(beaHome + "/oracle_common/bin/rcu -silent -dropRepository -databaseType ORACLE -connectString "+ rcudbstr +" -dbUser sys -dbRole sysdba -useSamePasswordForAllSchemaUsers true -schemaPrefix "+sprName+" -component STB -component IAU -component IAU_APPEND -component IAU_VIEWER -component OPSS -f <"+pwdfile)
#print "Schemas droped for user "+sprName

print "Creating schemas for user"+sprName
#os.system(beaHome + "/oracle_common/bin/rcu -silent -createRepository -connectString "+ rcudbstr +" -dbUser sys -dbRole sysdba 
#-useSamePasswordForAllSchemaUsers true -schemaPrefix "+sprName+" -component MDS -component IAU -component IAU_APPEND -component IAU_VIEWER 
#-component OPSS -component UMS -component WLS -component SOAINFRA -component STB -f < "+pwdfile)
print "Schemas created."
readTemplate(wlHome + "/common/templates/wls/wls.jar")

#=======================================================================================
# Configure the Administration Server and SSL port.
#
# To enable access by both local and remote processes, you should not set the
# listen address for the server instance (that is, it should be left blank or not set).
# In this case, the server instance will determine the address of the machine and
# listen on it.
#=======================================================================================

cd('Servers/AdminServer')
set('ListenAddress','s500lxhmlmm01.magazineluiza.intranet')
set('ListenPort', 9001)

create('AdminServer','SSL')
cd('SSL/AdminServer')
set('Enabled', 'False')
set('ListenPort', 9002)

print "Created AdminServer Config"

cd('/')
create('s500lxhmlmm01','Machine')
cd('/Machines/s500lxhmlmm01')
create('s500lxhmlmm01','NodeManager')

print "Created s500lxhmlmm01 machine Config"

cd('/')
create('s500lxhmlmm03','Machine')
cd('/Machines/s500lxhmlmm03')
create('s500lxhmlmm03','NodeManager')

print "Created s500lxhmlmm03 machine Config"

cd('NodeManager/s500lxhmlmm01')
set('NMType', 'SSL')
set('ListenPort',5559)
set('DebugEnabled', 'false')

assign('Server', 'AdminServer', 'Machine', 's500lxhmlmm01')
print 'Assigned AdminServer to NodeManager on port 5559'

cd('NodeManager/s500lxhmlmm03')
set('NMType', 'SSL')
set('ListenPort',5559)
set('DebugEnabled', 'false')


#=======================================================================================
# Define the user password for weblogic.
#=======================================================================================

cd('/')

cmo=cd('Security/base_domain/User/weblogic')

# This is weblogic password. Set it based on your preference

cmo.setPassword('Welcome1')
print 'Created user weblogic'
#=======================================================================================
# Write the domain and close the domain template.
#=======================================================================================

setOption('OverwriteDomain', 'true')
writeDomain(baseHome + '/domains/'+domainName)
closeTemplate()

print "Domain written and closed SUCCESS"

readDomain(baseHome + '/domains/'+domainName)
print "Domain read, adding JRF template"

#Uncomment below line if version is 12.1.2
#addTemplate(beaHome+'/oracle_common/common/templates/wls/oracle.jrf_template_12.1.2.jar')

#Uncomment below line if version is 12.1.3
addTemplate(beaHome+'/oracle_common/common/templates/wls/oracle.jrf_template_12.1.3.jar')

 

print "Creating local DS with user "+sprName+"_STB"

#cd('/')
#cd('/JDBCSystemResource/LocalSvcTblDataSource/JdbcResource/LocalSvcTblDataSource')
#cd('JDBCDriverParams/NO_NAME_0')
#set('DriverName','oracle.jdbc.OracleDriver')
#set('URL',dburl)

# Set here the password used for the schemas in the RCU execution. For this sample it is welcome1, but for your case you must set it to the right value, based in the contents of password.txt

#set('PasswordEncrypted', 'welcome1')
#cd('Properties/NO_NAME_0')
#cd('Property/user')
#cmo.setValue(sprName+'_STB')

print "Datasource LocalSvcTblDataSource created"

getDatabaseDefaults()
print "Executed getDatabaseDefaults()"
#cd('/')
#cd('JDBCSystemResource/opss-data-source/JdbcResource/opss-data-source')
#cd('JDBCDriverParams/NO_NAME_0')
#set('DriverName','oracle.jdbc.OracleDriver')
#set('URL', 'jdbc:oracle:thin:@localhost:1521/ORC112U')
#set('PasswordEncrypted', 'Welcome1')
#cd('Properties/NO_NAME_0')
#cd('Property/user')
#cmo.setValue('MIKE_OPSS')

#cd('/')
#cd('JDBCSystemResource/opss-audit-viewDS/JdbcResource/opss-audit-viewDS')
#cd('JDBCDriverParams/NO_NAME_0')
#set('DriverName','oracle.jdbc.OracleDriver')
#set('URL', 'jdbc:oracle:thin:@localhost:1521/ORC112U')
#set('PasswordEncrypted', 'Welcome1')
#cd('Properties/NO_NAME_0')
#cd('Property/user')
#cmo.setValue('MIKE_IAU_VIEWER')

#cd('/')
#cd('JDBCSystemResource/opss-audit-DBDS/JdbcResource/opss-audit-DBDS')
#cd('JDBCDriverParams/NO_NAME_0')
#set('DriverName','oracle.jdbc.OracleDriver')
#set('URL', 'jdbc:oracle:thin:@localhost:1521/ORC112U')
#set('PasswordEncrypted', 'Welcome1')
#cd('Properties/NO_NAME_0')
#cd('Property/user')
#cmo.setValue('MIKE_IAU_APPEND')

updateDomain()
closeDomain()
print "Executed updateDomain() and closeDomain() for JRF template"
print 'Adding EM Template to domain.'

readDomain(beaHome + '/user_projects/domains/'+domainName)
print "Executed readDomain()"

#Uncomment below line if version is 12.1.2
#addTemplate(beaHome+'/em/common/templates/wls/oracle.em_wls_template_12.1.2.jar')

#Uncomment below line if FMW version is 12.1.3
addTemplate(beaHome+'/em/common/templates/wls/oracle.em_wls_template_12.1.3.jar')

print "Executed addTemplate()"
updateDomain()
closeDomain()
print "Executed updateDomain() and closeDomain() for EM templated"

print "JRF template successfuly created !"

exit()
